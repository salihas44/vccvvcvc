fetch('data.json')
    .then(response => response.json())
    .then(data => {
        document.getElementById('title').value = data.title;
        document.getElementById('description').value = data.description;
        document.getElementById('content-input').value = data.content;
    });

document.getElementById('admin-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const updatedData = {
        title: document.getElementById('title').value,
        description: document.getElementById('description').value,
        content: document.getElementById('content-input').value
    };
    const blob = new Blob([JSON.stringify(updatedData, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'data.json';
    a.click();
});