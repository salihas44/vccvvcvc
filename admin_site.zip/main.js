fetch('data.json')
    .then(response => response.json())
    .then(data => {
        document.getElementById('site-title').textContent = data.title;
        document.getElementById('site-description').textContent = data.description;
        document.getElementById('content').innerHTML = data.content;
    });